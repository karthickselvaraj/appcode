package io.jenkins.plugins;

import hudson.console.ConsoleLogFilter;
import hudson.console.LineTransformationOutputStream;
import hudson.model.Action;
import hudson.model.Run;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;
import org.jenkinsci.plugins.workflow.cps.CpsFlowExecution;
import org.jenkinsci.plugins.workflow.cps.nodes.StepEndNode;
import org.jenkinsci.plugins.workflow.cps.nodes.StepStartNode;
import org.jenkinsci.plugins.workflow.flow.FlowExecutionOwner;
import org.jenkinsci.plugins.workflow.flow.GraphListener;
import org.jenkinsci.plugins.workflow.graph.FlowNode;

// @Extension
public class MicroStageListener implements GraphListener.Synchronous {
    private static final Logger LOGGER = Logger.getLogger(MicroStageListener.class.getName());
    private Map<String, Long> stageStartTimes = new HashMap<>();
    private Map<String, String> stageStartNodes = new HashMap<>();

    @Override
    public void onNewHead(FlowNode node) {
        if (node instanceof StepStartNode) {
            StepStartNode startNode = (StepStartNode) node;
            if (isStageNode(startNode)) {
                LOGGER.info("Stage started: " + startNode.getDisplayName() + " ID: " + startNode.getId());
                stageStartNodes.put(startNode.getId(), startNode.getDisplayName());
                stageStartTimes.put(startNode.getId(), System.currentTimeMillis());
                attachLogListener(startNode);
            }
        } else if (node instanceof StepEndNode) {
            StepEndNode endNode = (StepEndNode) node;
            String startNodeId = endNode.getStartNode().getId();
            String stageName = stageStartNodes.get(startNodeId);
            Long startTime = stageStartTimes.get(startNodeId);
            if (stageName != null && startTime != null) {
                long duration = System.currentTimeMillis() - startTime;
                LOGGER.info("Stage ended: " + stageName + " ID: " + startNodeId + " Duration: " + duration + " ms");
                stageStartNodes.remove(startNodeId);
                stageStartTimes.remove(startNodeId);
            } else {
                // LOGGER.info("Unmatched StageEndNode: " + endNode.getDisplayName() + " ID: " + endNode.getId());
            }
        }
    }

    private boolean isStageNode(StepStartNode node) {
        // Check if the start node represents a stage
        return node.getAction(org.jenkinsci.plugins.workflow.actions.LabelAction.class) != null;
    }

    private void attachLogListener(StepStartNode node) {
        try {
            FlowExecutionOwner owner = node.getExecution().getOwner();
            CpsFlowExecution cpsFlowExecution = (CpsFlowExecution) owner.get();
            Run<?, ?> run = (Run<?, ?>) cpsFlowExecution.getOwner().getExecutable();
            LOGGER.info("####### Attaching Listener");
            if (run != null) {
                LOGGER.info("Karthick nodeId " + node.getId());
                run.addAction(new LogAction(run, node.getId()));
            } else {
                LOGGER.info("######## RUN is null");
            }
        } catch (IOException e) {
            LOGGER.warning("Failed to attach log listener: " + e.getMessage());
        }
    }

    public static class LogAction extends ConsoleLogFilter implements Action {
        private final Run<?, ?> run;
        private final String stageNodeId;

        public LogAction(Run<?, ?> run, String stageNodeId) {
            this.run = run;
            this.stageNodeId = stageNodeId;
        }

        @Override
        public OutputStream decorateLogger(Run run, OutputStream logger) throws IOException, InterruptedException {
            return new LogCaptureOutputStream(logger, stageNodeId);
        }

        @Override
        public String getDisplayName() {
            return "Log Action";
        }

        @Override
        public String getIconFileName() {
            return null;
        }

        @Override
        public String getUrlName() {
            return null;
        }

        private static class LogCaptureOutputStream extends LineTransformationOutputStream {
            private final OutputStream logger;
            private final String stageNodeId;

            LogCaptureOutputStream(OutputStream logger, String stageNodeId) {
                this.logger = logger;
                this.stageNodeId = stageNodeId;
            }

            @Override
            protected void eol(byte[] b, int len) throws IOException {
                String logLine = new String(b, StandardCharsets.UTF_8);
                LOGGER.info("Log for stage " + stageNodeId + ": " + logLine);
                logger.write(b, 0, len);
            }

            @Override
            public void flush() throws IOException {
                logger.flush();
            }

            @Override
            public void close() throws IOException {
                super.close();
                logger.close();
            }
        }
    }
}
