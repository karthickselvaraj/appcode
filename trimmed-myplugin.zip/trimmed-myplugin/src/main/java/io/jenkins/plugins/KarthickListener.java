package io.jenkins.plugins;

import edu.umd.cs.findbugs.annotations.NonNull;
import java.util.List;
import java.util.logging.Logger;
import org.jenkinsci.plugins.workflow.flow.FlowExecution;
import org.jenkinsci.plugins.workflow.flow.FlowExecutionListener;
import org.jenkinsci.plugins.workflow.graph.FlowNode;

// @Extension
public class KarthickListener extends FlowExecutionListener {

    private static final Logger LOGGER = Logger.getLogger(KarthickListener.class.getName());

    @Override
    public void onRunning(@NonNull FlowExecution execution) {
        List<FlowNode> flowNodeList = execution.getCurrentHeads();
        for (FlowNode flowNode : flowNodeList) {
            LOGGER.info("Karthick " + flowNode.getId());
        }
    }

    @Override
    public void onCreated(@NonNull FlowExecution execution) {
        List<FlowNode> flowNodeList = execution.getCurrentHeads();
        for (FlowNode flowNode : flowNodeList) {
            LOGGER.info("Karthick " + flowNode.getId());
        }
        super.onCreated(execution);
    }
}
