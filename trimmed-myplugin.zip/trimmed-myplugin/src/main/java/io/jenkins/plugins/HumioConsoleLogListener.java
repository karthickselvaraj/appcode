package io.jenkins.plugins;

import hudson.console.ConsoleLogFilter;
import hudson.model.Run;
import java.io.OutputStream;
import java.util.Map;
import java.util.TreeMap;
import org.apache.commons.io.output.TeeOutputStream;

// @Extension
@SuppressWarnings("unused")
public class HumioConsoleLogListener extends ConsoleLogFilter {
    @Override
    public OutputStream decorateLogger(Run build, OutputStream logger) {
        if (HumioConfig.getInstance().getEnabled()) {

            Map<String, String> extraFields = new TreeMap<>();

            Util.addRunMetaData(build, extraFields);

            return new TeeOutputStream(
                    logger, new HumioOutputStream(build.getParent().getName(), build.getNumber(), extraFields));
        } else {
            return logger;
        }
    }
}
