package io.jenkins.plugins;

import hudson.Extension;
import java.io.IOException;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;
import org.jenkinsci.plugins.workflow.actions.LabelAction;
import org.jenkinsci.plugins.workflow.actions.LogAction;
import org.jenkinsci.plugins.workflow.cps.nodes.StepAtomNode;
import org.jenkinsci.plugins.workflow.flow.FlowExecution;
import org.jenkinsci.plugins.workflow.flow.FlowExecutionOwner;
import org.jenkinsci.plugins.workflow.flow.GraphListener;
import org.jenkinsci.plugins.workflow.graph.FlowNode;
import org.jenkinsci.plugins.workflow.job.WorkflowRun;

//@Extension
public class FlowNodeStatusListener implements GraphListener {

    private static final Logger LOGGER = Logger.getLogger(FlowNodeStatusListener.class.getName());

    private final Map<String, String> stageNodeIdMap = new HashMap<>();

    @Override
    public void onNewHead(FlowNode node) {
        if (node.getAction(LabelAction.class) != null) {
            String stageNodeId = node.getId();
            stageNodeIdMap.put(stageNodeId, stageNodeId);
        }
        if (node instanceof StepAtomNode) {
            handleFlowNodeStatusChange(node);
        }
    }

    private void handleFlowNodeStatusChange(FlowNode node) {
        try {
            if (node instanceof StepAtomNode) {
                StepAtomNode stepNode = (StepAtomNode) node;
                FlowExecution execution = stepNode.getExecution();
                FlowExecutionOwner owner = execution.getOwner();
                WorkflowRun run = (WorkflowRun) owner.getExecutable();
                String stageNodeId = getStageNodeId(stepNode);

                String log = getLogForNode(run, stepNode);
                LOGGER.info(stageNodeId + ": " + log);
                // emitLogToHttpEndpoint(stageNodeId, log, "RUNNING");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String getStageNodeId(FlowNode node) {
        for (FlowNode parent : node.getParents()) {
            if (stageNodeIdMap.containsKey(parent.getId())) {
                return stageNodeIdMap.get(parent.getId());
            }
        }
        return "Unknown Stage";
    }

    private String getLogForNode(WorkflowRun run, FlowNode node) {
        try {
            LogAction logAction = node.getAction(LogAction.class);
            if (logAction != null) {
                StringWriter writer = new StringWriter();
                long temp = logAction.getLogText().writeLogTo(0, writer);
                System.out.println(temp);
                return writer.toString();
            }
            return "";
        } catch (IOException e) {
            e.printStackTrace();
            return "Failed to retrieve log.";
        }
    }
}
