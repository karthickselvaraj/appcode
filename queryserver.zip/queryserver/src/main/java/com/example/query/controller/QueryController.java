package com.example.query.controller;

import com.example.query.service.QueryService;
import com.example.query.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/qeurt")
public class QueryController {

    @Autowired
    private QueryService queryService;

    @PostMapping("/execute")
    public String executeQuery(@RequestBody String sql) {
        return queryService.executeQuery(sql);
    }

    @GetMapping("/result/{executionId}")
    public List<Map<String,Object>> getResult(@RequestParam String executionId) {
        return queryService.getResults(executionId);
    }


}
