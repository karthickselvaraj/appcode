package com.example.query.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.type.TypeReference;
import org.springframework.stereotype.Service;
import redis.clients.jedis.Jedis;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@Service
public class QueryService {
    private final Jedis redisClient = new Jedis("localhost", 6379);
    private final AsyncQueryExecutor executor;

    public QueryService(AsyncQueryExecutor executor) {
        this.executor = executor;
    }

    public String executeQuery(String sql) {
        return executor.executedQuery(sql);
    }

    public boolean isQueryReady(String executionId) {
        return redisClient.exists(executionId);
    }

    public long removeQueryResult(String executionId) {
        return redisClient.del(executionId);
    }



    public List<Map<String, Object>> getResults(String executionId) {
        String resultsJson = redisClient.get(executionId);
        List<Map<String, Object>> result;
        if (resultsJson != null && !"LARGE_RESULT_SET".equals(resultsJson)) {
            try {
                result = new ObjectMapper().readValue(resultsJson, new TypeReference<List<Map<String, Object>>>() {});
                redisClient.del(executionId);
                return result;
            } catch (JsonProcessingException e) {
                throw new RuntimeException(e);
            }
        } else {
            return null;
        }
    }

    public boolean isLargeResultSet(String executionId) {
        return "LARGE_RESULT_SET".equals(redisClient.get(executionId));
    }
}

