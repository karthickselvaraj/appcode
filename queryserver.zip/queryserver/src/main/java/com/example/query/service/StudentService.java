package com.example.query.service;

import com.example.query.repository.Student;
import com.example.query.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import redis.clients.jedis.Jedis;

import java.io.IOException;

@Component
public class StudentService {

    @Autowired
    private QueryService queryService;

    @Autowired
    private StudentRepository repository;

    @Autowired
    private JdbcTemplate jdbcTemplate;
    public void saveStudent() throws IOException {
        String executionId = queryService.executeQuery("SELECT * from employee_commits;");

        while(queryService.isQueryReady(executionId) != true) {
            System.out.println("Result not yet ready");
            try {
                Thread.sleep(5);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
        System.out.println(queryService.getResults(executionId));
        System.out.println(queryService.removeQueryResult(executionId));

    }
}
