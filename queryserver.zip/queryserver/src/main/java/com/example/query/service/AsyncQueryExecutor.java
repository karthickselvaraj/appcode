package com.example.query.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
import redis.clients.jedis.Jedis;

import java.sql.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

@Component
public class AsyncQueryExecutor {

    @Autowired
    private JdbcTemplate jdbcTemplate;
    private final Jedis redisClient;
    private final ExecutorService executorService;
    private final ConcurrentHashMap<String, Future<?>> runningQueries = new ConcurrentHashMap<>();

    public AsyncQueryExecutor(@Value("${redisHost:localhost}") String redisHost,
                              @Value("${redisPort:6379}") int redisPort, JdbcTemplate jdbcTemplate) {
        this.redisClient = new Jedis(redisHost, redisPort);
        this.executorService = Executors.newFixedThreadPool(10);
    }

    public String executedQuery(String sql) {
        String executionId = UUID.randomUUID().toString();
        Future<?> future = executorService.submit(() -> {
           try {
               List<Map<String, Object>> results = runQuery(sql);
               if (results.size() <= 1000) {
                   String resultsJson = new ObjectMapper().writeValueAsString(results);
                   redisClient.setex(executionId, 3600, resultsJson); // Cache results for 1 hour
               } else {
                   redisClient.setex(executionId, 3600, "LARGE_RESULT_SET"); // Indicate large result set
               }
           } catch (Exception e) {
               // Handle exceptions
           } finally {
               runningQueries.remove(executionId);
           }
        });
        runningQueries.put(executionId, future);
        return executionId;
    }

    private List<Map<String, Object>> runQuery(String sql) {
        return jdbcTemplate.query(sql, (RowMapper<Map<String, Object>>) (rs, rowNum) -> {
            Map<String, Object> rowMap = new HashMap<>();
            int columnCount = rs.getMetaData().getColumnCount();
            for (int i = 1; i <= columnCount; i++) {
                rowMap.put(rs.getMetaData().getColumnName(i), rs.getObject(i));
            }
            return rowMap;
        });
    }


    public void cancelQuery(String executionId) {
        Future<?> future = runningQueries.get(executionId);
        if (future != null) {
            future.cancel(true);
            runningQueries.remove(executionId);
            redisClient.del(executionId); // Remove partial results from Redis
            redisClient.del(executionId + ":remaining"); // Remove remaining results from Redis
        }
    }
}
